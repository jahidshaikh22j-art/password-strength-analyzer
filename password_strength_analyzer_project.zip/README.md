# Password Strength Analyzer

A Python tool that checks password strength based on:
- Length
- Uppercase letters
- Lowercase letters
- Numbers
- Special characters

## Run
```bash
python password_strength_analyzer.py
```
